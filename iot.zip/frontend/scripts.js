const apiEndpoint = 'http://localhost:3000/api';

// Variáveis globais
let nomeUsuario = '';
let tipoPlanta = '';

// Alternar para a tela de monitoramento
function mostrarTelaMonitoramento() {
    document.getElementById('tela-inicial').style.display = 'none'; // Oculta a tela inicial
    document.getElementById('tela-monitoramento').style.display = 'block'; // Exibe a tela de monitoramento
    document.getElementById('nome-usuario-planta').innerText = `Usuário: ${nomeUsuario} | Planta: ${tipoPlanta}`;
  }

// Função para iniciar o monitoramento
document.getElementById('btn-iniciar-monitoramento').addEventListener('click', async () => {
    nomeUsuario = document.getElementById('nome-usuario').value;
    tipoPlanta = document.getElementById('selecionar-planta').value;
  
    console.log('Nome do usuário:', nomeUsuario); // Debug
    console.log('Tipo de planta selecionado:', tipoPlanta); // Debug
  
    if (!nomeUsuario || !tipoPlanta) {
      alert('Por favor, insira seu nome e selecione um tipo de planta.');
      return;
    }
  
    try {
      const response = await fetch(`${apiEndpoint}/selecionar-planta`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ tipoPlanta }),
      });
  
      const data = await response.json();
      console.log('Resposta do backend:', data); // Debug
      alert(data.message);
      mostrarTelaMonitoramento();
    } catch (error) {
      console.error('Erro ao selecionar planta:', error);
    }
  });

// Função para buscar dados de umidade
async function fetchMoistureData() {
  try {
    const response = await fetch(`${apiEndpoint}/monitorar`);
    const data = await response.json();

    updateBar(data.umidade);
    updateStatus(data.irrigacao);
  } catch (error) {
    console.error('Erro ao buscar dados:', error);
  }
}

// Função para atualizar a barra de umidade
function updateBar(umidade) {
  const bar = document.getElementById('bar');
  const moisturePercentage = Math.min(Math.max((umidade / 1023) * 100, 0), 100);
  bar.style.width = `${moisturePercentage}%`;
}

// Função para atualizar o status da irrigação
function updateStatus(irrigacao) {
  const statusMessage = document.getElementById('status-message');
  statusMessage.innerText = irrigacao
    ? `Irrigação ativada para ${tipoPlanta}! 💧`
    : `Irrigação desativada para ${tipoPlanta}. 🌱`;
}

// Função para consultar dados históricos
document.getElementById('consultar-dados').addEventListener('click', async () => {
  try {
    const response = await fetch(`${apiEndpoint}/dados`);
    const data = await response.json();
    document.getElementById('dados').textContent = JSON.stringify(data, null, 2);
  } catch (error) {
    console.error('Erro ao consultar dados:', error);
  }
});

// Atualizar a cada 5 segundos
setInterval(fetchMoistureData, 5000);

// Primeira chamada para buscar dados imediatamente
fetchMoistureData();